//
//  ViewController.m
//  单个滚动选择器
//
//  Created by 毛织网 on 2018/6/21.
//  Copyright © 2018年 陈帝运. All rights reserved.
//

#import "ViewController.h"
#import "CDYPickView.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
    
    NSArray *array = @[@"2015年2月8日",@"2015年5月20日",@"2015年8月15日",@"2016年3月2日",@"2017年10月20日",@"2015年5月20日",@"2015年8月15日",@"2016年3月2日",@"2017年10月20日",@"2015年5月20日",@"2015年8月15日",@"2016年3月2日",@"2017年10月20日"];
    CDYPickView *pickview = [CDYPickView new];
    [pickview.dataArray addObjectsFromArray:array];
    pickview.selectedRow = @"2";
    pickview.tishilabelstr=@"民族";
    pickview.back = ^(NSString *date){
        
        NSLog(@"日期====%@",date);
    };
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
