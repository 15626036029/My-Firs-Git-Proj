//
//  CDYPickView.h
//  单个滚动选择器
//
//  Created by 毛织网 on 2018/6/21.
//  Copyright © 2018年 陈帝运. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDYPickView : UIView
@property(nonatomic,strong) void(^back)(NSString *);

@property(nonatomic,strong) NSMutableArray *dataArray;
@property(nonatomic,strong) NSString *selectedRow;
@property(nonatomic,strong) NSString *tishilabelstr;
@property(nonatomic,strong) UILabel *tishilabel;
+(instancetype)setPickViewDate;
@end
